const i={version:"0.1.0-rc.23",buildTimestamp:"2026-05-16T08:26:43.965Z",gitCommit:"e3b5ff3",sourceOrigin:"https://github.com/David-Lzy/AI_Usage_Dashboard"};export{i as B};
